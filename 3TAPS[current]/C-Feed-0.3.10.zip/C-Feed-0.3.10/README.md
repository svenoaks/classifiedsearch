C-Feed
======

A Craigslist search app for Android OS

Copyright (C) 2013 John Krause
jkrause@lavabit.com

Contact me about any bugs, code improvements, or suggestions.

If you are grateful for this software and would like to donate please [click here](https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=jkrause%40lavabit%2ecom&lc=US&item_name=JKrause%20Software&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted) to give a paypal donation

Artwork is licencsed under Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0) which is detailed under ART_LICENCSE.txt [click here for more information](http://creativecommons.org/licenses/by-sa/3.0/)

Software license info is in the LICENSE.txt file, below is a brief description of the GPLv3 in use for C-Feed

C-Feed program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License version 3
as published by the Free Software Foundation.

C-Feed is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License <http://www.gnu.org/licenses/gpl-3.0.txt>
for more details.

![Main page](/Screenshots/Screenshot_2013-06-03-13-15-22.png "Main page")
![Options section](/Screenshots/Screenshot_2013-06-03-13-15-30.png "Options")
![States](/Screenshots/Screenshot_2013-06-03-13-15-43.png "States")
![Categories page](/Screenshots/Screenshot_2013-06-03-13-17-00.png "Categories")
![Results List](/Screenshots/Screenshot_2013-06-03-13-17-15.png "Results")


